import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  /**
   * Vérifie si l'utilisateur est authentifié.
   * Si l'utilisateur n'est pas authentifié, redirige vers la page de connexion.
   * Si l'utilisateur est authentifié, autorise l'accès à la route demandée.
   */
  canActivate(): boolean {
    const isAuthenticated = !!localStorage.getItem('userToken'); // Vérifie si le token existe dans localStorage

    if (!isAuthenticated) {
      // Si non authentifié, redirige vers la page de connexion
      this.router.navigate(['/login']);
      return false;
    }

    // Si authentifié, l'utilisateur peut accéder à la route
    return true;
  }
}
