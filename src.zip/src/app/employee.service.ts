import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

// Interface pour typage des employés
export interface Employee {
  _id?: string; // ID optionnel (auto-généré par MongoDB)
  nom: string;
  cin: string;
  poste: string;
  service: string;
  forfait: string;
  forfaitInternet: string;
  numTelephone?: string; // Optionnel si non attribué
  serialNumber?: string; // Optionnel si non attribué
}

// Interface pour typage des données de SIM
export interface Sim {
  serialNumber: string;
  numTelephone?: string; // Optionnel si non attribué
}

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private apiUrl = 'http://localhost:3000/api/employees'; // API des employés
  private simApiUrl = 'http://localhost:3000/api/sims'; // API des SIMs

  constructor(private http: HttpClient) {}

  /**
   * Attribuer un numéro de téléphone à une SIM.
   * @param formData Les données contenant le numéro de série et le numéro de téléphone.
   * @returns Observable de la réponse de l'API.
   */
  assignNumber(formData: { serialNumber: string; numTelephone: string }): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-number`, formData).pipe(
      catchError((error) => {
        console.error('Erreur lors de l\'attribution du numéro:', error);
        return throwError(() => new Error('Erreur d\'attribution de numéro.'));
      })
    );
  }

  /**
   * Attribuer une SIM à un employé.
   * @param formData Les données du formulaire contenant les détails de l'employé et de la SIM.
   * @returns Observable de la réponse de l'API.
   */
  assignSim(formData: Employee): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-sim`, formData).pipe(
      catchError((error) => {
        console.error('Erreur lors de l\'attribution de la SIM:', error);
        return throwError(() => new Error('Erreur d\'attribution de la SIM.'));
      })
    );
  }

  /**
   * Récupérer la liste des employés depuis le backend.
   * @returns Observable contenant la liste des employés.
   */
  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.apiUrl).pipe(
      catchError((error) => {
        console.error('Erreur lors de la récupération des employés:', error);
        return throwError(() => new Error('Impossible de récupérer les employés.'));
      })
    );
  }

  /**
   * Mettre à jour un employé.
   * @param id L'identifiant de l'employé.
   * @param updatedData Les données mises à jour (ex. : numéro de téléphone).
   * @returns Observable de la réponse de l'API.
   */
  updateEmployee(id: string, updatedData: Partial<Employee>): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, updatedData).pipe(
      catchError((error) => {
        console.error('Erreur lors de la mise à jour de l\'employé:', error);
        return throwError(() => new Error('Erreur de mise à jour de l\'employé.'));
      })
    );
  }
}
