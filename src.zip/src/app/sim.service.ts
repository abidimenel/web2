import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SimService {
  getAllSims(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/all`); // Assurez-vous que l'URL est correcte
  }
  
  // URL de votre backend local (remplacez-la par l'URL de production si nécessaire)
  private apiUrl = 'http://localhost:5000/api/sim';  // Vérifiez que cette URL correspond à votre API

  constructor(private http: HttpClient) { }

  /**
   * Récupérer la liste des SIMs
   */
  getSims(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  /**
   * Ajouter une nouvelle SIM
   * @param simData - Les données de la SIM à créer
   */
  createSim(simData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, simData);
  }

  /**
   * Attribuer une SIM à un employé
   * @param simData - Les données de la SIM à attribuer
   */
  assignSim(simData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/assign`, simData);
  }

  /**
   * Attribuer un numéro à une SIM
   * @param simData - Les données de la SIM à attribuer
   */
  assignSimNumber(simData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/assign-number`, simData);
  }

  /**
   * Supprimer une SIM par ID
   * @param id - L'ID de la SIM à supprimer
   */
  deleteSim(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
