

// src/app/available-number/available-number.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-available-number',
  templateUrl: './available-number.component.html',
  styleUrls: ['./available-number.component.css']
})
export class AvailableNumberComponent {
  availableNumber = { number: '' };
  availableNumbers = [
    { number: '92211480' },
    { number: '987654321' },
    { number: '945125470' }
  ];

  addAvailableNumber() {
    if (this.availableNumber.number) {
      this.availableNumbers.push({ ...this.availableNumber });
    }
    this.availableNumber = { number: '' };
  }
}
