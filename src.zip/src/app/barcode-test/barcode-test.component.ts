import { Component } from '@angular/core';

@Component({
  selector: 'app-barcode-test',  // Ensure the selector is unique and correctly set
  templateUrl: './barcode-test.component.html',
  styleUrls: ['./barcode-test.component.css'],
})
export class BarcodeTestComponent {
  scannedQRCode: string | null = null;

  handleQRCodeResult(event: any): void {
    this.scannedQRCode = event ? event.text : '';
  }
}
