import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BarcodeTestComponent } from './barcode-test.component';

describe('BarcodeTestComponent', () => {
  let component: BarcodeTestComponent;
  let fixture: ComponentFixture<BarcodeTestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BarcodeTestComponent]
    });
    fixture = TestBed.createComponent(BarcodeTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
